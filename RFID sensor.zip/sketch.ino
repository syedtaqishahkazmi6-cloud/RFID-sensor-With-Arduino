#include <SPI.h>
#include <MFRC522.h>

#define RST_PIN         9          
#define SS_PIN          10         

MFRC522 mfrc522(SS_PIN, RST_PIN);

void setup() {
  Serial.begin(9600);
  SPI.begin();
  mfrc522.PCD_Init();
  Serial.println("Ready to scan...");
}

void loop() {
  // Reset the loop if no new card is present
  if ( ! mfrc522.PICC_IsNewCardPresent() || ! mfrc522.PICC_ReadCardSerial()) {
    return;
  }

  // Convert the UID bytes into a readable String
  String content = "";
  for (byte i = 0; i < mfrc522.uid.size; i++) {
     content.concat(String(mfrc522.uid.uidByte[i] < 0x10 ? " 0" : " "));
     content.concat(String(mfrc522.uid.uidByte[i], HEX));
  }
  content.toUpperCase();
  
  Serial.println("Detected UID:" + content);

  // --- ASSIGN TASKS HERE ---
  
  if (content.substring(1) == "33 5A 72 1B") { // Change this to your Card 1 UID
    performTaskA();
  }
  
  else if (content.substring(1) == "A1 B2 C3 D4") { // Change this to your Card 2 UID
    performTaskB();
  }
  
  else {
    Serial.println("Unknown card. Access Denied.");
  }

  delay(1000); // Short delay to prevent multiple reads
}

// Define what happens for each card
void performTaskA() {
  Serial.println("Task A: Opening the vault...");
  // Add code here: e.g., digitalWrite(relayPin, HIGH);
}

void performTaskB() {
  Serial.println("Task B: Activating System...");
  // Add code here: e.g., tone(buzzerPin, 1000);
}